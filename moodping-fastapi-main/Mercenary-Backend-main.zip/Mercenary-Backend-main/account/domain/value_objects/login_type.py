from enum import Enum

class LoginType(Enum):
    KAKAO = "KAKAO"
    GOOGLE = "GOOGLE"
